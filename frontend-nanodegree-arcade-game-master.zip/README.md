# Frogger Arcade Game

## Introdoction
Frogger Arcade is a variation of the classic Frogger arcade game.

## Goals/Winning
In this game the goal is simple, get the character to move across the gray bricks towards the water without getting hit by the enemy bugs. The user's score increases by 100 point for each level passed. The speed of enemy bugs also increase with each level at the start of each game.

## Movement and Controls
Users move the character by using the main up/right/left/down arrow keys on their keyboard. You can change the player character with "enter" keyboard.

## Authors
* **Udacity** - Initial work
* **Gal Minyan** - Functionality and design

## License
This project is a part of "Front-End Web Developer Nanodegree" at Udacity!